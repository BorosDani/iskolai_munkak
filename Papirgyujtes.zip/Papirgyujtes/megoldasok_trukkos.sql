﻿A feladatok megoldására elkészített SQL parancsokat illessze be a feladat sorszáma után!

1. feladat:
SELECT COUNT(DISTINCT(tanulo)) AS "Papírgyűjtésben résztvevők száma"
	FROM leadasok

2. feladat:
SELECT COUNT(*) AS "A-val kezdődő nevűek száma"
	FROM tanulok
    WHERE nev LIKE("A%")

3. feladat:
SELECT LEFT(nev, 1) AS "Kezdőbetű", COUNT(*) AS "Darabszám"
	FROM tanulok
    GROUP BY Kezdőbetű
    ORDER BY Kezdőbetű

4. feladat:

5. feladat:

6. feladat: