﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ultrabalaton
{
    class Program
    {
        struct BalatonStruktura
        {
            public string Versenyzo;
            public string Kategoria;
            public int Rajtszam;
            public int Versenyido;
            public int TavSzazalek;
        }
        static void Main(string[] args)
        {
            ultrabalaton();
            Console.ReadKey();
        }

        private static void ultrabalaton() 
        {
            StreamReader olvasocsatorna = new StreamReader(@"Z:\programozas\ultrabalaton\ub2017egyeni.txt");

            string elsosor = olvasocsatorna.ReadLine();
            string sor;

            List<BalatonStruktura> adatok = new List<BalatonStruktura>();
            string[] darabol;

            while (!olvasocsatorna.EndOfStream) 
            {
                sor = olvasocsatorna.ReadLine();
                darabol = sor.Split(';');
            }
        }
    }
}
