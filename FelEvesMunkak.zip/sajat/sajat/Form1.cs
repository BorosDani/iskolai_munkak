﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sajat
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void karakter_btn_OnKeyUp(object sender, KeyEventArgs e)
        {
            if (this.ClientSize.Width - karakter_btn.Width > karakter_btn.Location.X && this.ClientSize.Height - karakter_btn.Height > karakter_btn.Location.Y && karakter_btn.Location.X > 0 && karakter_btn.Location.Y > 0)
            {
                if (e.KeyCode == Keys.Right)
                {
                    karakter_btn.Location = new Point(karakter_btn.Location.X + 30, karakter_btn.Location.Y);
                }
                if (e.KeyCode == Keys.Left)
                {
                    karakter_btn.Location = new Point(karakter_btn.Location.X - 30, karakter_btn.Location.Y);
                }
                if (e.KeyCode == Keys.Up)
                {
                    karakter_btn.Location = new Point(karakter_btn.Location.X, karakter_btn.Location.Y - 30);
                }
                if (e.KeyCode == Keys.Down)
                {
                    karakter_btn.Location = new Point(karakter_btn.Location.X, karakter_btn.Location.Y + 30);
                }
            }

            if (this.ClientSize.Width - karakter_btn.Width < karakter_btn.Location.X) 
            {
            }
        }
    }
}
