﻿namespace kilepes
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.kilepes_btn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // kilepes_btn
            // 
            this.kilepes_btn.Location = new System.Drawing.Point(50, 50);
            this.kilepes_btn.Name = "kilepes_btn";
            this.kilepes_btn.Size = new System.Drawing.Size(75, 23);
            this.kilepes_btn.TabIndex = 0;
            this.kilepes_btn.Text = "Kilépés";
            this.kilepes_btn.UseVisualStyleBackColor = true;
            this.kilepes_btn.Click += new System.EventHandler(this.kilepes_btn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(184, 161);
            this.Controls.Add(this.kilepes_btn);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Location = new System.Drawing.Point(100, 300);
            this.Name = "Form1";
            this.Text = "Fejlett kilépő program";
            this.MouseEnter += new System.EventHandler(this.Form1_MouseEnter);
            this.MouseLeave += new System.EventHandler(this.Form1_MouseLeave);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button kilepes_btn;
    }
}

