﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace footgolf
{
    class Program
    {
        static void Main(string[] args)
        {
            footgolf();
            Console.ReadLine();
        }

        private static void footgolf() 
        {
            feladat2();
            feladat3();
            Console.WriteLine("\n");
            feladat4();
            Console.WriteLine("\n");
            feladat6();
            Console.WriteLine("\n");
        }

        struct FootgolfStruktura 
        {
            public string Nev;
            public string Kategoria;
            public string EgyesuletNev;
            public string Pontok;
        }
        static List<FootgolfStruktura> adatok = new List<FootgolfStruktura>();

        private static void feladat2() 
        {
            StreamReader olvasocsatorna = new StreamReader("fob2016.txt");
            string sor;

            string[] darabol;

            while (!olvasocsatorna.EndOfStream) 
            {
                sor = olvasocsatorna.ReadLine();
                darabol = sor.Split(';');

                FootgolfStruktura golf = new FootgolfStruktura();

                golf.Nev = darabol[0];
                golf.Kategoria = darabol[1];
                golf.EgyesuletNev = darabol[2];
                golf.Pontok = darabol[3] + ";" + darabol[4] + ";" + darabol[5] 
                    + ";" + darabol[6] + ";" + darabol[7] + ";" 
                    + darabol[8] + ";" + darabol[9] + ";" + darabol[10];

                adatok.Add(golf);
            }
        }

        private static void feladat3() 
        {
            Console.WriteLine($"3. Feladat: Versenyzők száma: {adatok.Count()}");
        }

        private static void feladat4() 
        {
            double noi_versenyzok_szama = 0;

            for (int i = 0; i < adatok.Count(); i++)
            {
                if (adatok[i].Kategoria == "Noi")
                {
                    noi_versenyzok_szama++;
                }
            }
            Console.WriteLine($"4. Feladat: A női versenyzők aránya: {Math.Round((noi_versenyzok_szama / adatok.Count()) * 100, 2)}%");
        }

        //5. Feladat
        static int Osszpontszam(string pontszamok) 
        {
            string[] pontok = pontszamok.Split(';');
            int jelenlegi_kisebb_pont = int.Parse(pontok[0]);
            int osszpont = 0;

            for (int i = 0; i < pontok.Length; i++)
            {
                osszpont = 0;
                for (int j = 0; j < pontok.Length; j++)
                {
                    if (int.Parse(pontok[j]) < jelenlegi_kisebb_pont) 
                    {
                        jelenlegi_kisebb_pont = int.Parse(pontok[j]);
                    }
                    if (int.Parse(pontok[j]) > 0) 
                    {
                        osszpont += int.Parse(pontok[j]);
                    }
                }
            }
            return osszpont;
        }

        private static void feladat6() 
        {
            for (int i = 0; i < adatok.Count(); i++)
            {
                Console.WriteLine(i + 1 + "    " + Osszpontszam(adatok[i].Pontok));
            }
        }
    }
}
