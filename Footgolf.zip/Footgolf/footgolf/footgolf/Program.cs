﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace footgolf
{
    class Program
    {
        static void Main(string[] args)
        {
            footgolf();
            Console.ReadLine();
        }

        private static void footgolf() 
        {
            feladat2();
            Console.WriteLine();
        }

        private static void feladat2() 
        {

        }
    }
}
