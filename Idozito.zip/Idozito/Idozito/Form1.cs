﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Idozito
{
    public partial class Form1 : Form
    {
        DateTime startIdo;
        TimeSpan elteltIdo, taroltElteltIdo;
        public Form1()
        {
            InitializeComponent();
        }

        private void startBtn_MouseClick(object sender, MouseEventArgs e)
        {
            timer1.Enabled = true;
            startBtn.Enabled = false;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            oraLbl.Text = DateTime.Now.ToString("HH:mm:ss:fff");
        }

        private void stopBtn_MouseClick(object sender, MouseEventArgs e)
        {
            timer1.Enabled = false;
            startBtn.Enabled = true;
        }




        private void startBtn2_MouseClick(object sender, MouseEventArgs e)
        {
            startIdo = DateTime.Now;
            startBtn2.Enabled = false;
            pauseBtn.Enabled = true;
            timer2.Enabled = true;
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            oraLbl.Text = DateTime.Now.ToString("HH:mm:ss:fff");
        }

        private void pauseBtn_MouseClick(object sender, MouseEventArgs e)
        {
            pauseBtn.Enabled = false;
            timer2.Enabled = false;
            startBtn2.Enabled = true;
        }

        private void stopBtn2_MouseClick(object sender, MouseEventArgs e)
        {
            pauseBtn.Enabled = false;
            timer2.Enabled = false;
            startBtn2.Enabled = true;
        }
    }
}
