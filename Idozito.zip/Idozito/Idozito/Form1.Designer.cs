﻿namespace Idozito
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.startBtn = new System.Windows.Forms.Button();
            this.stopBtn = new System.Windows.Forms.Button();
            this.oraLbl = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.oraTPg = new System.Windows.Forms.TabPage();
            this.StopperTPg = new System.Windows.Forms.TabPage();
            this.pauseBtn = new System.Windows.Forms.Button();
            this.stopperLbl = new System.Windows.Forms.Label();
            this.StopperStopBtnd = new System.Windows.Forms.Button();
            this.startBtn2 = new System.Windows.Forms.Button();
            this.MozgoPTg = new System.Windows.Forms.TabPage();
            this.MozgoFLBL = new System.Windows.Forms.Label();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.xy = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.oraTPg.SuspendLayout();
            this.StopperTPg.SuspendLayout();
            this.MozgoPTg.SuspendLayout();
            this.SuspendLayout();
            // 
            // startBtn
            // 
            this.startBtn.Location = new System.Drawing.Point(143, 269);
            this.startBtn.Name = "startBtn";
            this.startBtn.Size = new System.Drawing.Size(75, 23);
            this.startBtn.TabIndex = 0;
            this.startBtn.Text = "Start";
            this.startBtn.UseVisualStyleBackColor = true;
            this.startBtn.MouseClick += new System.Windows.Forms.MouseEventHandler(this.startBtn_MouseClick);
            // 
            // stopBtn
            // 
            this.stopBtn.Location = new System.Drawing.Point(333, 269);
            this.stopBtn.Name = "stopBtn";
            this.stopBtn.Size = new System.Drawing.Size(75, 23);
            this.stopBtn.TabIndex = 1;
            this.stopBtn.Text = "Stop";
            this.stopBtn.UseVisualStyleBackColor = true;
            this.stopBtn.MouseClick += new System.Windows.Forms.MouseEventHandler(this.stopBtn_MouseClick);
            // 
            // oraLbl
            // 
            this.oraLbl.AutoSize = true;
            this.oraLbl.BackColor = System.Drawing.Color.Cornsilk;
            this.oraLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.oraLbl.ForeColor = System.Drawing.SystemColors.ControlText;
            this.oraLbl.Location = new System.Drawing.Point(220, 181);
            this.oraLbl.Name = "oraLbl";
            this.oraLbl.Size = new System.Drawing.Size(45, 20);
            this.oraLbl.TabIndex = 2;
            this.oraLbl.Text = "[óra]";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.oraTPg);
            this.tabControl1.Controls.Add(this.StopperTPg);
            this.tabControl1.Controls.Add(this.MozgoPTg);
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(580, 460);
            this.tabControl1.TabIndex = 5;
            // 
            // oraTPg
            // 
            this.oraTPg.Controls.Add(this.oraLbl);
            this.oraTPg.Controls.Add(this.stopBtn);
            this.oraTPg.Controls.Add(this.startBtn);
            this.oraTPg.Location = new System.Drawing.Point(4, 22);
            this.oraTPg.Name = "oraTPg";
            this.oraTPg.Padding = new System.Windows.Forms.Padding(3);
            this.oraTPg.Size = new System.Drawing.Size(572, 434);
            this.oraTPg.TabIndex = 0;
            this.oraTPg.Text = "Óra";
            this.oraTPg.UseVisualStyleBackColor = true;
            // 
            // StopperTPg
            // 
            this.StopperTPg.Controls.Add(this.pauseBtn);
            this.StopperTPg.Controls.Add(this.stopperLbl);
            this.StopperTPg.Controls.Add(this.StopperStopBtnd);
            this.StopperTPg.Controls.Add(this.startBtn2);
            this.StopperTPg.Location = new System.Drawing.Point(4, 22);
            this.StopperTPg.Name = "StopperTPg";
            this.StopperTPg.Padding = new System.Windows.Forms.Padding(3);
            this.StopperTPg.Size = new System.Drawing.Size(432, 434);
            this.StopperTPg.TabIndex = 1;
            this.StopperTPg.Text = "Stopper";
            this.StopperTPg.UseVisualStyleBackColor = true;
            // 
            // pauseBtn
            // 
            this.pauseBtn.Location = new System.Drawing.Point(243, 290);
            this.pauseBtn.Name = "pauseBtn";
            this.pauseBtn.Size = new System.Drawing.Size(75, 23);
            this.pauseBtn.TabIndex = 3;
            this.pauseBtn.Text = "Pause";
            this.pauseBtn.UseVisualStyleBackColor = true;
            this.pauseBtn.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pauseBtn_MouseClick);
            // 
            // stopperLbl
            // 
            this.stopperLbl.AutoSize = true;
            this.stopperLbl.BackColor = System.Drawing.Color.Cornsilk;
            this.stopperLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.stopperLbl.Location = new System.Drawing.Point(235, 186);
            this.stopperLbl.Name = "stopperLbl";
            this.stopperLbl.Size = new System.Drawing.Size(83, 20);
            this.stopperLbl.TabIndex = 2;
            this.stopperLbl.Text = "[Stopper]";
            // 
            // StopperStopBtnd
            // 
            this.StopperStopBtnd.Location = new System.Drawing.Point(362, 290);
            this.StopperStopBtnd.Name = "StopperStopBtnd";
            this.StopperStopBtnd.Size = new System.Drawing.Size(75, 23);
            this.StopperStopBtnd.TabIndex = 1;
            this.StopperStopBtnd.Text = "Stop";
            this.StopperStopBtnd.UseVisualStyleBackColor = true;
            this.StopperStopBtnd.MouseClick += new System.Windows.Forms.MouseEventHandler(this.StopperStop_MouseClick);
            // 
            // startBtn2
            // 
            this.startBtn2.Location = new System.Drawing.Point(132, 290);
            this.startBtn2.Name = "startBtn2";
            this.startBtn2.Size = new System.Drawing.Size(75, 23);
            this.startBtn2.TabIndex = 0;
            this.startBtn2.Text = "Start";
            this.startBtn2.UseVisualStyleBackColor = true;
            this.startBtn2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.startBtn2_MouseClick);
            // 
            // MozgoPTg
            // 
            this.MozgoPTg.Controls.Add(this.xy);
            this.MozgoPTg.Controls.Add(this.MozgoFLBL);
            this.MozgoPTg.Location = new System.Drawing.Point(4, 22);
            this.MozgoPTg.Name = "MozgoPTg";
            this.MozgoPTg.Padding = new System.Windows.Forms.Padding(3);
            this.MozgoPTg.Size = new System.Drawing.Size(572, 434);
            this.MozgoPTg.TabIndex = 2;
            this.MozgoPTg.Text = "Mozgószöveg";
            this.MozgoPTg.UseVisualStyleBackColor = true;
            // 
            // MozgoFLBL
            // 
            this.MozgoFLBL.AutoSize = true;
            this.MozgoFLBL.BackColor = System.Drawing.Color.Red;
            this.MozgoFLBL.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.MozgoFLBL.ForeColor = System.Drawing.SystemColors.Control;
            this.MozgoFLBL.Location = new System.Drawing.Point(217, 201);
            this.MozgoFLBL.Name = "MozgoFLBL";
            this.MozgoFLBL.Size = new System.Drawing.Size(129, 24);
            this.MozgoFLBL.TabIndex = 0;
            this.MozgoFLBL.Text = "Mozgó felirat";
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // timer3
            // 
            this.timer3.Interval = 10;
            this.timer3.Tick += new System.EventHandler(this.timer3_Tick);
            // 
            // xy
            // 
            this.xy.AutoSize = true;
            this.xy.Location = new System.Drawing.Point(474, 7);
            this.xy.Name = "xy";
            this.xy.Size = new System.Drawing.Size(35, 13);
            this.xy.TabIndex = 1;
            this.xy.Text = "label1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(584, 461);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Óra";
            this.tabControl1.ResumeLayout(false);
            this.oraTPg.ResumeLayout(false);
            this.oraTPg.PerformLayout();
            this.StopperTPg.ResumeLayout(false);
            this.StopperTPg.PerformLayout();
            this.MozgoPTg.ResumeLayout(false);
            this.MozgoPTg.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button startBtn;
        private System.Windows.Forms.Button stopBtn;
        private System.Windows.Forms.Label oraLbl;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage oraTPg;
        private System.Windows.Forms.TabPage StopperTPg;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Label stopperLbl;
        private System.Windows.Forms.Button StopperStopBtnd;
        private System.Windows.Forms.Button startBtn2;
        private System.Windows.Forms.Button pauseBtn;
        private System.Windows.Forms.TabPage MozgoPTg;
        private System.Windows.Forms.Timer timer3;
        private System.Windows.Forms.Label MozgoFLBL;
        private System.Windows.Forms.Label xy;
    }
}

