﻿namespace Gyak_vezerlok
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.MeretPgn = new System.Windows.Forms.TabPage();
            this.KepMozgatasPgn = new System.Windows.Forms.TabPage();
            this.meretHSb = new System.Windows.Forms.HScrollBar();
            this.meretVSb = new System.Windows.Forms.VScrollBar();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.beallitBtn = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.MeretPgn.SuspendLayout();
            this.KepMozgatasPgn.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.MeretPgn);
            this.tabControl1.Controls.Add(this.KepMozgatasPgn);
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(985, 564);
            this.tabControl1.TabIndex = 0;
            // 
            // MeretPgn
            // 
            this.MeretPgn.Controls.Add(this.panel1);
            this.MeretPgn.Controls.Add(this.meretVSb);
            this.MeretPgn.Controls.Add(this.meretHSb);
            this.MeretPgn.Location = new System.Drawing.Point(4, 22);
            this.MeretPgn.Name = "MeretPgn";
            this.MeretPgn.Padding = new System.Windows.Forms.Padding(3);
            this.MeretPgn.Size = new System.Drawing.Size(977, 538);
            this.MeretPgn.TabIndex = 0;
            this.MeretPgn.Text = "Méretezés";
            this.MeretPgn.UseVisualStyleBackColor = true;
            // 
            // KepMozgatasPgn
            // 
            this.KepMozgatasPgn.Controls.Add(this.beallitBtn);
            this.KepMozgatasPgn.Controls.Add(this.textBox1);
            this.KepMozgatasPgn.Controls.Add(this.panel2);
            this.KepMozgatasPgn.Location = new System.Drawing.Point(4, 22);
            this.KepMozgatasPgn.Name = "KepMozgatasPgn";
            this.KepMozgatasPgn.Padding = new System.Windows.Forms.Padding(3);
            this.KepMozgatasPgn.Size = new System.Drawing.Size(977, 538);
            this.KepMozgatasPgn.TabIndex = 1;
            this.KepMozgatasPgn.Text = "Kép mozgatás";
            this.KepMozgatasPgn.UseVisualStyleBackColor = true;
            // 
            // meretHSb
            // 
            this.meretHSb.Location = new System.Drawing.Point(22, 17);
            this.meretHSb.Maximum = 900;
            this.meretHSb.Minimum = 100;
            this.meretHSb.Name = "meretHSb";
            this.meretHSb.Size = new System.Drawing.Size(915, 17);
            this.meretHSb.TabIndex = 0;
            this.meretHSb.Value = 100;
            this.meretHSb.Scroll += new System.Windows.Forms.ScrollEventHandler(this.meretHSb_Scroll);
            // 
            // meretVSb
            // 
            this.meretVSb.LargeChange = 1;
            this.meretVSb.Location = new System.Drawing.Point(937, 17);
            this.meretVSb.Maximum = 480;
            this.meretVSb.Minimum = 100;
            this.meretVSb.Name = "meretVSb";
            this.meretVSb.Size = new System.Drawing.Size(17, 513);
            this.meretVSb.TabIndex = 1;
            this.meretVSb.Value = 100;
            this.meretVSb.Scroll += new System.Windows.Forms.ScrollEventHandler(this.meretVSb_Scroll);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel1.Location = new System.Drawing.Point(22, 46);
            this.panel1.MaximumSize = new System.Drawing.Size(900, 480);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(100, 100);
            this.panel1.TabIndex = 2;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel2.Location = new System.Drawing.Point(22, 68);
            this.panel2.MaximumSize = new System.Drawing.Size(900, 480);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(100, 100);
            this.panel2.TabIndex = 5;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(22, 26);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(838, 20);
            this.textBox1.TabIndex = 6;
            // 
            // beallitBtn
            // 
            this.beallitBtn.Location = new System.Drawing.Point(879, 26);
            this.beallitBtn.Name = "beallitBtn";
            this.beallitBtn.Size = new System.Drawing.Size(75, 23);
            this.beallitBtn.TabIndex = 7;
            this.beallitBtn.Text = "Kép (URL)";
            this.beallitBtn.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 561);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.MeretPgn.ResumeLayout(false);
            this.KepMozgatasPgn.ResumeLayout(false);
            this.KepMozgatasPgn.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage MeretPgn;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.VScrollBar meretVSb;
        private System.Windows.Forms.HScrollBar meretHSb;
        private System.Windows.Forms.TabPage KepMozgatasPgn;
        private System.Windows.Forms.Button beallitBtn;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Panel panel2;
    }
}

