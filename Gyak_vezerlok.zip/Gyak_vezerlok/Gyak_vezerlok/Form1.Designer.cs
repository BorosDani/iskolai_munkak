﻿namespace Gyak_vezerlok
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.MeretPgn = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.meretVSb = new System.Windows.Forms.VScrollBar();
            this.meretHSb = new System.Windows.Forms.HScrollBar();
            this.KepMozgatasPgn = new System.Windows.Forms.TabPage();
            this.kepPb = new System.Windows.Forms.PictureBox();
            this.beallitBtn = new System.Windows.Forms.Button();
            this.utvonalTxt = new System.Windows.Forms.TextBox();
            this.sudokuPgn = new System.Windows.Forms.TabPage();
            this.ellBtn = new System.Windows.Forms.Button();
            this.kezdoallapotTxt = new System.Windows.Forms.TextBox();
            this.meretTxt = new System.Windows.Forms.TextBox();
            this.plusBtn = new System.Windows.Forms.Button();
            this.minusBtn = new System.Windows.Forms.Button();
            this.hosszLbl = new System.Windows.Forms.Label();
            this.kezdoallapotLbl = new System.Windows.Forms.Label();
            this.ujFeladvanyMeretLbl = new System.Windows.Forms.Label();
            this.listaPgn = new System.Windows.Forms.TabPage();
            this.torles2Btn = new System.Windows.Forms.Button();
            this.rendelesBtn = new System.Windows.Forms.Button();
            this.hozzaad2Btn = new System.Windows.Forms.Button();
            this.rendelesLb = new System.Windows.Forms.ListBox();
            this.valasztoCb = new System.Windows.Forms.ComboBox();
            this.kiuritesBtn = new System.Windows.Forms.Button();
            this.infoLbl = new System.Windows.Forms.Label();
            this.torlesBtn = new System.Windows.Forms.Button();
            this.hozzaadBtn = new System.Windows.Forms.Button();
            this.termekTxt = new System.Windows.Forms.TextBox();
            this.bevasarloListaLb = new System.Windows.Forms.ListBox();
            this.PeldaLb = new System.Windows.Forms.ListBox();
            this.moziPgn = new System.Windows.Forms.TabPage();
            this.masolBtn = new System.Windows.Forms.Button();
            this.helyNud = new System.Windows.Forms.NumericUpDown();
            this.beszurBtn = new System.Windows.Forms.Button();
            this.keresBtn = new System.Windows.Forms.Button();
            this.megnezettFilmLb = new System.Windows.Forms.ListBox();
            this.athelyezBtn = new System.Windows.Forms.Button();
            this.filmKiuritesBtn = new System.Windows.Forms.Button();
            this.filmTorlesBtn = new System.Windows.Forms.Button();
            this.felveszBtn = new System.Windows.Forms.Button();
            this.topMoziLb = new System.Windows.Forms.ListBox();
            this.filmNevTxt = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.webbPgn = new System.Windows.Forms.TabPage();
            this.label1 = new System.Windows.Forms.Label();
            this.ugrasBtn = new System.Windows.Forms.Button();
            this.urlCimCB = new System.Windows.Forms.ComboBox();
            this.webBrowser = new System.Windows.Forms.WebBrowser();
            this.tabControl1.SuspendLayout();
            this.MeretPgn.SuspendLayout();
            this.KepMozgatasPgn.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kepPb)).BeginInit();
            this.sudokuPgn.SuspendLayout();
            this.listaPgn.SuspendLayout();
            this.moziPgn.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.helyNud)).BeginInit();
            this.webbPgn.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.MeretPgn);
            this.tabControl1.Controls.Add(this.KepMozgatasPgn);
            this.tabControl1.Controls.Add(this.sudokuPgn);
            this.tabControl1.Controls.Add(this.listaPgn);
            this.tabControl1.Controls.Add(this.moziPgn);
            this.tabControl1.Controls.Add(this.webbPgn);
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(985, 564);
            this.tabControl1.TabIndex = 0;
            // 
            // MeretPgn
            // 
            this.MeretPgn.Controls.Add(this.panel1);
            this.MeretPgn.Controls.Add(this.meretVSb);
            this.MeretPgn.Controls.Add(this.meretHSb);
            this.MeretPgn.Location = new System.Drawing.Point(4, 22);
            this.MeretPgn.Name = "MeretPgn";
            this.MeretPgn.Padding = new System.Windows.Forms.Padding(3);
            this.MeretPgn.Size = new System.Drawing.Size(977, 538);
            this.MeretPgn.TabIndex = 0;
            this.MeretPgn.Text = "Méretezés";
            this.MeretPgn.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel1.Location = new System.Drawing.Point(22, 46);
            this.panel1.MaximumSize = new System.Drawing.Size(900, 480);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(100, 100);
            this.panel1.TabIndex = 2;
            // 
            // meretVSb
            // 
            this.meretVSb.LargeChange = 1;
            this.meretVSb.Location = new System.Drawing.Point(937, 17);
            this.meretVSb.Maximum = 480;
            this.meretVSb.Minimum = 100;
            this.meretVSb.Name = "meretVSb";
            this.meretVSb.Size = new System.Drawing.Size(17, 513);
            this.meretVSb.TabIndex = 1;
            this.meretVSb.Value = 100;
            this.meretVSb.Scroll += new System.Windows.Forms.ScrollEventHandler(this.meretVSb_Scroll);
            // 
            // meretHSb
            // 
            this.meretHSb.Location = new System.Drawing.Point(22, 17);
            this.meretHSb.Maximum = 900;
            this.meretHSb.Minimum = 100;
            this.meretHSb.Name = "meretHSb";
            this.meretHSb.Size = new System.Drawing.Size(915, 17);
            this.meretHSb.TabIndex = 0;
            this.meretHSb.Value = 100;
            this.meretHSb.Scroll += new System.Windows.Forms.ScrollEventHandler(this.meretHSb_Scroll);
            // 
            // KepMozgatasPgn
            // 
            this.KepMozgatasPgn.Controls.Add(this.kepPb);
            this.KepMozgatasPgn.Controls.Add(this.beallitBtn);
            this.KepMozgatasPgn.Controls.Add(this.utvonalTxt);
            this.KepMozgatasPgn.Location = new System.Drawing.Point(4, 22);
            this.KepMozgatasPgn.Name = "KepMozgatasPgn";
            this.KepMozgatasPgn.Padding = new System.Windows.Forms.Padding(3);
            this.KepMozgatasPgn.Size = new System.Drawing.Size(977, 538);
            this.KepMozgatasPgn.TabIndex = 1;
            this.KepMozgatasPgn.Text = "Kép mozgatás";
            this.KepMozgatasPgn.UseVisualStyleBackColor = true;
            // 
            // kepPb
            // 
            this.kepPb.BackColor = System.Drawing.Color.Black;
            this.kepPb.Location = new System.Drawing.Point(15, 41);
            this.kepPb.Name = "kepPb";
            this.kepPb.Size = new System.Drawing.Size(200, 177);
            this.kepPb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.kepPb.TabIndex = 8;
            this.kepPb.TabStop = false;
            this.kepPb.Click += new System.EventHandler(this.kepPb_Click);
            // 
            // beallitBtn
            // 
            this.beallitBtn.Location = new System.Drawing.Point(860, 14);
            this.beallitBtn.Name = "beallitBtn";
            this.beallitBtn.Size = new System.Drawing.Size(75, 23);
            this.beallitBtn.TabIndex = 7;
            this.beallitBtn.Text = "Kép (URL)";
            this.beallitBtn.UseVisualStyleBackColor = true;
            this.beallitBtn.Click += new System.EventHandler(this.beallitBtn_Click);
            // 
            // utvonalTxt
            // 
            this.utvonalTxt.Location = new System.Drawing.Point(15, 15);
            this.utvonalTxt.Name = "utvonalTxt";
            this.utvonalTxt.Size = new System.Drawing.Size(838, 20);
            this.utvonalTxt.TabIndex = 6;
            // 
            // sudokuPgn
            // 
            this.sudokuPgn.Controls.Add(this.ellBtn);
            this.sudokuPgn.Controls.Add(this.kezdoallapotTxt);
            this.sudokuPgn.Controls.Add(this.meretTxt);
            this.sudokuPgn.Controls.Add(this.plusBtn);
            this.sudokuPgn.Controls.Add(this.minusBtn);
            this.sudokuPgn.Controls.Add(this.hosszLbl);
            this.sudokuPgn.Controls.Add(this.kezdoallapotLbl);
            this.sudokuPgn.Controls.Add(this.ujFeladvanyMeretLbl);
            this.sudokuPgn.Location = new System.Drawing.Point(4, 22);
            this.sudokuPgn.Name = "sudokuPgn";
            this.sudokuPgn.Padding = new System.Windows.Forms.Padding(3);
            this.sudokuPgn.Size = new System.Drawing.Size(977, 538);
            this.sudokuPgn.TabIndex = 2;
            this.sudokuPgn.Text = "Sudoku";
            this.sudokuPgn.UseVisualStyleBackColor = true;
            // 
            // ellBtn
            // 
            this.ellBtn.Location = new System.Drawing.Point(313, 155);
            this.ellBtn.Name = "ellBtn";
            this.ellBtn.Size = new System.Drawing.Size(100, 20);
            this.ellBtn.TabIndex = 7;
            this.ellBtn.Text = "Ellenőrzés";
            this.ellBtn.UseVisualStyleBackColor = true;
            this.ellBtn.Click += new System.EventHandler(this.ellBtn_Click);
            // 
            // kezdoallapotTxt
            // 
            this.kezdoallapotTxt.Location = new System.Drawing.Point(69, 127);
            this.kezdoallapotTxt.Name = "kezdoallapotTxt";
            this.kezdoallapotTxt.Size = new System.Drawing.Size(344, 20);
            this.kezdoallapotTxt.TabIndex = 6;
            this.kezdoallapotTxt.TextChanged += new System.EventHandler(this.kezdoallapotTxt_TextChanged);
            // 
            // meretTxt
            // 
            this.meretTxt.AcceptsReturn = true;
            this.meretTxt.Location = new System.Drawing.Point(209, 63);
            this.meretTxt.Name = "meretTxt";
            this.meretTxt.Size = new System.Drawing.Size(20, 20);
            this.meretTxt.TabIndex = 5;
            this.meretTxt.Text = "4";
            this.meretTxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // plusBtn
            // 
            this.plusBtn.Location = new System.Drawing.Point(235, 63);
            this.plusBtn.Name = "plusBtn";
            this.plusBtn.Size = new System.Drawing.Size(20, 20);
            this.plusBtn.TabIndex = 4;
            this.plusBtn.Text = "+";
            this.plusBtn.UseVisualStyleBackColor = true;
            this.plusBtn.Click += new System.EventHandler(this.plusBtn_Click);
            // 
            // minusBtn
            // 
            this.minusBtn.Location = new System.Drawing.Point(183, 62);
            this.minusBtn.Name = "minusBtn";
            this.minusBtn.Size = new System.Drawing.Size(20, 20);
            this.minusBtn.TabIndex = 3;
            this.minusBtn.Text = "-";
            this.minusBtn.UseVisualStyleBackColor = true;
            this.minusBtn.Click += new System.EventHandler(this.minusBtn_Click);
            // 
            // hosszLbl
            // 
            this.hosszLbl.AutoSize = true;
            this.hosszLbl.Location = new System.Drawing.Point(66, 155);
            this.hosszLbl.Name = "hosszLbl";
            this.hosszLbl.Size = new System.Drawing.Size(39, 13);
            this.hosszLbl.TabIndex = 2;
            this.hosszLbl.Text = "Hossz:";
            // 
            // kezdoallapotLbl
            // 
            this.kezdoallapotLbl.AutoSize = true;
            this.kezdoallapotLbl.Location = new System.Drawing.Point(66, 111);
            this.kezdoallapotLbl.Name = "kezdoallapotLbl";
            this.kezdoallapotLbl.Size = new System.Drawing.Size(71, 13);
            this.kezdoallapotLbl.TabIndex = 1;
            this.kezdoallapotLbl.Text = "Kezdőállapot:";
            // 
            // ujFeladvanyMeretLbl
            // 
            this.ujFeladvanyMeretLbl.AutoSize = true;
            this.ujFeladvanyMeretLbl.Location = new System.Drawing.Point(66, 67);
            this.ujFeladvanyMeretLbl.Name = "ujFeladvanyMeretLbl";
            this.ujFeladvanyMeretLbl.Size = new System.Drawing.Size(98, 13);
            this.ujFeladvanyMeretLbl.TabIndex = 0;
            this.ujFeladvanyMeretLbl.Text = "Új feladvány méret:";
            // 
            // listaPgn
            // 
            this.listaPgn.Controls.Add(this.torles2Btn);
            this.listaPgn.Controls.Add(this.rendelesBtn);
            this.listaPgn.Controls.Add(this.hozzaad2Btn);
            this.listaPgn.Controls.Add(this.rendelesLb);
            this.listaPgn.Controls.Add(this.valasztoCb);
            this.listaPgn.Controls.Add(this.kiuritesBtn);
            this.listaPgn.Controls.Add(this.infoLbl);
            this.listaPgn.Controls.Add(this.torlesBtn);
            this.listaPgn.Controls.Add(this.hozzaadBtn);
            this.listaPgn.Controls.Add(this.termekTxt);
            this.listaPgn.Controls.Add(this.bevasarloListaLb);
            this.listaPgn.Controls.Add(this.PeldaLb);
            this.listaPgn.Location = new System.Drawing.Point(4, 22);
            this.listaPgn.Name = "listaPgn";
            this.listaPgn.Size = new System.Drawing.Size(977, 538);
            this.listaPgn.TabIndex = 3;
            this.listaPgn.Text = "Lista";
            this.listaPgn.UseVisualStyleBackColor = true;
            // 
            // torles2Btn
            // 
            this.torles2Btn.ForeColor = System.Drawing.Color.Red;
            this.torles2Btn.Location = new System.Drawing.Point(572, 407);
            this.torles2Btn.Name = "torles2Btn";
            this.torles2Btn.Size = new System.Drawing.Size(82, 23);
            this.torles2Btn.TabIndex = 16;
            this.torles2Btn.Text = "Törlés";
            this.torles2Btn.UseVisualStyleBackColor = true;
            this.torles2Btn.Click += new System.EventHandler(this.torles2Btn_Click);
            // 
            // rendelesBtn
            // 
            this.rendelesBtn.Location = new System.Drawing.Point(737, 407);
            this.rendelesBtn.Name = "rendelesBtn";
            this.rendelesBtn.Size = new System.Drawing.Size(82, 23);
            this.rendelesBtn.TabIndex = 15;
            this.rendelesBtn.Text = "Rendelés";
            this.rendelesBtn.UseVisualStyleBackColor = true;
            this.rendelesBtn.Click += new System.EventHandler(this.rendelesBtn_Click);
            // 
            // hozzaad2Btn
            // 
            this.hozzaad2Btn.Location = new System.Drawing.Point(825, 174);
            this.hozzaad2Btn.Name = "hozzaad2Btn";
            this.hozzaad2Btn.Size = new System.Drawing.Size(57, 23);
            this.hozzaad2Btn.TabIndex = 14;
            this.hozzaad2Btn.Text = "Hozzáad";
            this.hozzaad2Btn.UseVisualStyleBackColor = true;
            this.hozzaad2Btn.Click += new System.EventHandler(this.hozzaad2Btn_Click);
            // 
            // rendelesLb
            // 
            this.rendelesLb.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.rendelesLb.ForeColor = System.Drawing.Color.Teal;
            this.rendelesLb.FormattingEnabled = true;
            this.rendelesLb.Location = new System.Drawing.Point(572, 227);
            this.rendelesLb.Name = "rendelesLb";
            this.rendelesLb.Size = new System.Drawing.Size(247, 160);
            this.rendelesLb.TabIndex = 13;
            // 
            // valasztoCb
            // 
            this.valasztoCb.FormattingEnabled = true;
            this.valasztoCb.Location = new System.Drawing.Point(572, 175);
            this.valasztoCb.Name = "valasztoCb";
            this.valasztoCb.Size = new System.Drawing.Size(247, 21);
            this.valasztoCb.TabIndex = 12;
            // 
            // kiuritesBtn
            // 
            this.kiuritesBtn.BackColor = System.Drawing.Color.Maroon;
            this.kiuritesBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.kiuritesBtn.Location = new System.Drawing.Point(20, 424);
            this.kiuritesBtn.Name = "kiuritesBtn";
            this.kiuritesBtn.Size = new System.Drawing.Size(135, 23);
            this.kiuritesBtn.TabIndex = 11;
            this.kiuritesBtn.Text = "Bevásárló lista kiüritése";
            this.kiuritesBtn.UseVisualStyleBackColor = false;
            this.kiuritesBtn.Click += new System.EventHandler(this.kiuritesBtn_Click);
            // 
            // infoLbl
            // 
            this.infoLbl.AutoSize = true;
            this.infoLbl.Location = new System.Drawing.Point(77, 211);
            this.infoLbl.Name = "infoLbl";
            this.infoLbl.Size = new System.Drawing.Size(94, 13);
            this.infoLbl.TabIndex = 10;
            this.infoLbl.Text = "[Törlés Információ]";
            // 
            // torlesBtn
            // 
            this.torlesBtn.Location = new System.Drawing.Point(199, 424);
            this.torlesBtn.Name = "torlesBtn";
            this.torlesBtn.Size = new System.Drawing.Size(131, 23);
            this.torlesBtn.TabIndex = 9;
            this.torlesBtn.Text = "Termék törlése a listából";
            this.torlesBtn.UseVisualStyleBackColor = true;
            this.torlesBtn.Click += new System.EventHandler(this.torlesBtn_Click);
            // 
            // hozzaadBtn
            // 
            this.hozzaadBtn.Location = new System.Drawing.Point(273, 175);
            this.hozzaadBtn.Name = "hozzaadBtn";
            this.hozzaadBtn.Size = new System.Drawing.Size(57, 23);
            this.hozzaadBtn.TabIndex = 8;
            this.hozzaadBtn.Text = "Hozzáad";
            this.hozzaadBtn.UseVisualStyleBackColor = true;
            this.hozzaadBtn.Click += new System.EventHandler(this.hozzaadBtn_Click);
            // 
            // termekTxt
            // 
            this.termekTxt.Location = new System.Drawing.Point(20, 176);
            this.termekTxt.Name = "termekTxt";
            this.termekTxt.Size = new System.Drawing.Size(247, 20);
            this.termekTxt.TabIndex = 7;
            this.termekTxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.termekTxt_KeyDown);
            // 
            // bevasarloListaLb
            // 
            this.bevasarloListaLb.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.bevasarloListaLb.ForeColor = System.Drawing.Color.Teal;
            this.bevasarloListaLb.FormattingEnabled = true;
            this.bevasarloListaLb.Location = new System.Drawing.Point(20, 227);
            this.bevasarloListaLb.Name = "bevasarloListaLb";
            this.bevasarloListaLb.Size = new System.Drawing.Size(310, 160);
            this.bevasarloListaLb.TabIndex = 6;
            this.bevasarloListaLb.SelectedValueChanged += new System.EventHandler(this.bevasarloListaLb_SelectedValueChanged);
            // 
            // PeldaLb
            // 
            this.PeldaLb.FormattingEnabled = true;
            this.PeldaLb.Items.AddRange(new object[] {
            "       ----------------- Példa Lista -----------------",
            "elso",
            "harmadik",
            "masodik",
            "negyedik",
            "otodik"});
            this.PeldaLb.Location = new System.Drawing.Point(20, 20);
            this.PeldaLb.Name = "PeldaLb";
            this.PeldaLb.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.PeldaLb.Size = new System.Drawing.Size(229, 82);
            this.PeldaLb.TabIndex = 0;
            // 
            // moziPgn
            // 
            this.moziPgn.Controls.Add(this.masolBtn);
            this.moziPgn.Controls.Add(this.helyNud);
            this.moziPgn.Controls.Add(this.beszurBtn);
            this.moziPgn.Controls.Add(this.keresBtn);
            this.moziPgn.Controls.Add(this.megnezettFilmLb);
            this.moziPgn.Controls.Add(this.athelyezBtn);
            this.moziPgn.Controls.Add(this.filmKiuritesBtn);
            this.moziPgn.Controls.Add(this.filmTorlesBtn);
            this.moziPgn.Controls.Add(this.felveszBtn);
            this.moziPgn.Controls.Add(this.topMoziLb);
            this.moziPgn.Controls.Add(this.filmNevTxt);
            this.moziPgn.Location = new System.Drawing.Point(4, 22);
            this.moziPgn.Name = "moziPgn";
            this.moziPgn.Padding = new System.Windows.Forms.Padding(3);
            this.moziPgn.Size = new System.Drawing.Size(977, 538);
            this.moziPgn.TabIndex = 4;
            this.moziPgn.Text = "Mozi filmek";
            this.moziPgn.UseVisualStyleBackColor = true;
            // 
            // masolBtn
            // 
            this.masolBtn.Location = new System.Drawing.Point(356, 290);
            this.masolBtn.Name = "masolBtn";
            this.masolBtn.Size = new System.Drawing.Size(75, 23);
            this.masolBtn.TabIndex = 10;
            this.masolBtn.Text = "Átmásol";
            this.masolBtn.UseVisualStyleBackColor = true;
            this.masolBtn.Click += new System.EventHandler(this.masolBtn_Click);
            // 
            // helyNud
            // 
            this.helyNud.Location = new System.Drawing.Point(356, 63);
            this.helyNud.Name = "helyNud";
            this.helyNud.Size = new System.Drawing.Size(75, 20);
            this.helyNud.TabIndex = 9;
            this.helyNud.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // beszurBtn
            // 
            this.beszurBtn.Location = new System.Drawing.Point(356, 147);
            this.beszurBtn.Name = "beszurBtn";
            this.beszurBtn.Size = new System.Drawing.Size(75, 23);
            this.beszurBtn.TabIndex = 8;
            this.beszurBtn.Text = "Beszúr";
            this.beszurBtn.UseVisualStyleBackColor = true;
            this.beszurBtn.Click += new System.EventHandler(this.beszurBtn_Click);
            // 
            // keresBtn
            // 
            this.keresBtn.Location = new System.Drawing.Point(356, 348);
            this.keresBtn.Name = "keresBtn";
            this.keresBtn.Size = new System.Drawing.Size(75, 23);
            this.keresBtn.TabIndex = 7;
            this.keresBtn.Text = "Keresés";
            this.keresBtn.UseVisualStyleBackColor = true;
            this.keresBtn.Click += new System.EventHandler(this.keresBtn_Click);
            // 
            // megnezettFilmLb
            // 
            this.megnezettFilmLb.FormattingEnabled = true;
            this.megnezettFilmLb.Location = new System.Drawing.Point(461, 63);
            this.megnezettFilmLb.Name = "megnezettFilmLb";
            this.megnezettFilmLb.Size = new System.Drawing.Size(261, 329);
            this.megnezettFilmLb.TabIndex = 6;
            // 
            // athelyezBtn
            // 
            this.athelyezBtn.Location = new System.Drawing.Point(356, 319);
            this.athelyezBtn.Name = "athelyezBtn";
            this.athelyezBtn.Size = new System.Drawing.Size(75, 23);
            this.athelyezBtn.TabIndex = 5;
            this.athelyezBtn.Text = "Áthelyez";
            this.athelyezBtn.UseVisualStyleBackColor = true;
            this.athelyezBtn.Click += new System.EventHandler(this.athelyezBtn_Click);
            // 
            // filmKiuritesBtn
            // 
            this.filmKiuritesBtn.Location = new System.Drawing.Point(356, 205);
            this.filmKiuritesBtn.Name = "filmKiuritesBtn";
            this.filmKiuritesBtn.Size = new System.Drawing.Size(75, 23);
            this.filmKiuritesBtn.TabIndex = 4;
            this.filmKiuritesBtn.Text = "Kiűrítés";
            this.filmKiuritesBtn.UseVisualStyleBackColor = true;
            this.filmKiuritesBtn.Click += new System.EventHandler(this.filmKiuritesBtn_Click);
            // 
            // filmTorlesBtn
            // 
            this.filmTorlesBtn.Location = new System.Drawing.Point(356, 176);
            this.filmTorlesBtn.Name = "filmTorlesBtn";
            this.filmTorlesBtn.Size = new System.Drawing.Size(75, 23);
            this.filmTorlesBtn.TabIndex = 3;
            this.filmTorlesBtn.Text = "Törlés";
            this.filmTorlesBtn.UseVisualStyleBackColor = true;
            this.filmTorlesBtn.Click += new System.EventHandler(this.filmTorlesBtn_Click);
            // 
            // felveszBtn
            // 
            this.felveszBtn.Location = new System.Drawing.Point(356, 118);
            this.felveszBtn.Name = "felveszBtn";
            this.felveszBtn.Size = new System.Drawing.Size(75, 23);
            this.felveszBtn.TabIndex = 2;
            this.felveszBtn.Text = "Felvesz";
            this.felveszBtn.UseVisualStyleBackColor = true;
            this.felveszBtn.Click += new System.EventHandler(this.felveszBtn_Click);
            // 
            // topMoziLb
            // 
            this.topMoziLb.FormattingEnabled = true;
            this.topMoziLb.Items.AddRange(new object[] {
            "Mortal Kombat",
            "A bontóbrigád",
            "Birmingham bandája: A halhatatlan férfi",
            "Senki",
            "Jurassic World: Újjászületés"});
            this.topMoziLb.Location = new System.Drawing.Point(63, 102);
            this.topMoziLb.Name = "topMoziLb";
            this.topMoziLb.Size = new System.Drawing.Size(261, 290);
            this.topMoziLb.TabIndex = 1;
            // 
            // filmNevTxt
            // 
            this.filmNevTxt.Location = new System.Drawing.Point(63, 64);
            this.filmNevTxt.Name = "filmNevTxt";
            this.filmNevTxt.Size = new System.Drawing.Size(261, 20);
            this.filmNevTxt.TabIndex = 0;
            // 
            // timer1
            // 
            this.timer1.Interval = 10;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // webbPgn
            // 
            this.webbPgn.Controls.Add(this.webBrowser);
            this.webbPgn.Controls.Add(this.urlCimCB);
            this.webbPgn.Controls.Add(this.ugrasBtn);
            this.webbPgn.Controls.Add(this.label1);
            this.webbPgn.Location = new System.Drawing.Point(4, 22);
            this.webbPgn.Name = "webbPgn";
            this.webbPgn.Padding = new System.Windows.Forms.Padding(3);
            this.webbPgn.Size = new System.Drawing.Size(977, 538);
            this.webbPgn.TabIndex = 5;
            this.webbPgn.Text = "Webböngésző";
            this.webbPgn.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(23, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(32, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "URL:";
            // 
            // ugrasBtn
            // 
            this.ugrasBtn.Location = new System.Drawing.Point(853, 20);
            this.ugrasBtn.Name = "ugrasBtn";
            this.ugrasBtn.Size = new System.Drawing.Size(75, 23);
            this.ugrasBtn.TabIndex = 1;
            this.ugrasBtn.Text = "Ugrás";
            this.ugrasBtn.UseVisualStyleBackColor = true;
            this.ugrasBtn.Click += new System.EventHandler(this.ugrasBtn_Click);
            // 
            // urlCimCB
            // 
            this.urlCimCB.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.urlCimCB.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.AllUrl;
            this.urlCimCB.FormattingEnabled = true;
            this.urlCimCB.Location = new System.Drawing.Point(61, 21);
            this.urlCimCB.Name = "urlCimCB";
            this.urlCimCB.Size = new System.Drawing.Size(786, 21);
            this.urlCimCB.TabIndex = 3;
            // 
            // webBrowser
            // 
            this.webBrowser.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.webBrowser.Location = new System.Drawing.Point(3, 87);
            this.webBrowser.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser.Name = "webBrowser";
            this.webBrowser.Size = new System.Drawing.Size(971, 448);
            this.webBrowser.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 561);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.MeretPgn.ResumeLayout(false);
            this.KepMozgatasPgn.ResumeLayout(false);
            this.KepMozgatasPgn.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kepPb)).EndInit();
            this.sudokuPgn.ResumeLayout(false);
            this.sudokuPgn.PerformLayout();
            this.listaPgn.ResumeLayout(false);
            this.listaPgn.PerformLayout();
            this.moziPgn.ResumeLayout(false);
            this.moziPgn.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.helyNud)).EndInit();
            this.webbPgn.ResumeLayout(false);
            this.webbPgn.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage MeretPgn;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.VScrollBar meretVSb;
        private System.Windows.Forms.HScrollBar meretHSb;
        private System.Windows.Forms.TabPage KepMozgatasPgn;
        private System.Windows.Forms.Button beallitBtn;
        private System.Windows.Forms.TextBox utvonalTxt;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox kepPb;
        private System.Windows.Forms.TabPage sudokuPgn;
        private System.Windows.Forms.Button ellBtn;
        private System.Windows.Forms.TextBox kezdoallapotTxt;
        private System.Windows.Forms.TextBox meretTxt;
        private System.Windows.Forms.Button plusBtn;
        private System.Windows.Forms.Button minusBtn;
        private System.Windows.Forms.Label hosszLbl;
        private System.Windows.Forms.Label kezdoallapotLbl;
        private System.Windows.Forms.Label ujFeladvanyMeretLbl;
        private System.Windows.Forms.TabPage listaPgn;
        private System.Windows.Forms.Button kiuritesBtn;
        private System.Windows.Forms.Label infoLbl;
        private System.Windows.Forms.Button torlesBtn;
        private System.Windows.Forms.Button hozzaadBtn;
        private System.Windows.Forms.TextBox termekTxt;
        private System.Windows.Forms.ListBox bevasarloListaLb;
        private System.Windows.Forms.ListBox PeldaLb;
        private System.Windows.Forms.ComboBox valasztoCb;
        private System.Windows.Forms.Button hozzaad2Btn;
        private System.Windows.Forms.ListBox rendelesLb;
        private System.Windows.Forms.Button rendelesBtn;
        private System.Windows.Forms.Button torles2Btn;
        private System.Windows.Forms.TabPage moziPgn;
        private System.Windows.Forms.Button beszurBtn;
        private System.Windows.Forms.Button keresBtn;
        private System.Windows.Forms.ListBox megnezettFilmLb;
        private System.Windows.Forms.Button athelyezBtn;
        private System.Windows.Forms.Button filmKiuritesBtn;
        private System.Windows.Forms.Button filmTorlesBtn;
        private System.Windows.Forms.Button felveszBtn;
        private System.Windows.Forms.ListBox topMoziLb;
        private System.Windows.Forms.TextBox filmNevTxt;
        private System.Windows.Forms.NumericUpDown helyNud;
        private System.Windows.Forms.Button masolBtn;
        private System.Windows.Forms.TabPage webbPgn;
        private System.Windows.Forms.WebBrowser webBrowser;
        private System.Windows.Forms.ComboBox urlCimCB;
        private System.Windows.Forms.Button ugrasBtn;
        private System.Windows.Forms.Label label1;
    }
}

