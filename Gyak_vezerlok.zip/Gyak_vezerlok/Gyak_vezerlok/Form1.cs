﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gyak_vezerlok
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            //Kép mozgatás
            timer1.Enabled = true;

            Random rnd = new Random();
            int r = rnd.Next(0, 255);
            int g = rnd.Next(0, 255);
            int b = rnd.Next(0, 255);
            kepPb.BackColor = Color.FromArgb(r, g, b);

            //Sudoku
            meretTxt.Enabled = false;


            //Lista (Bevásárló lista)
            termekTxt.Text = "- - - Írd be a terméket - - -";
            bevasarloListaLb.Enabled = false;
            infoLbl.Visible = false;

            //Mozi filmek
            helyNud.Maximum = topMoziLb.Items.Count + 1;
            helyNud.Minimum = 1;
        }

        //Méretezés
        private void meretHSb_Scroll(object sender, ScrollEventArgs e)
        {
            panel1.Width = meretHSb.Value;
        }

        private void meretVSb_Scroll(object sender, ScrollEventArgs e)
        {
            panel1.Height = meretVSb.Value;
        }







        //Kép mozgatás
        int x = 2;
        int y = 2;
        private void timer1_Tick(object sender, EventArgs e)
        {
            Random rnd = new Random();
            int r = rnd.Next(0, 255);
            int g = rnd.Next(0, 255);
            int b = rnd.Next(0, 255);

            if (kepPb.Right >= KepMozgatasPgn.Width)
            {
                x = -2;
                kepPb.BackColor = Color.FromArgb(r, g, b);
            }
            else if (kepPb.Left <= 0) 
            {
                x = 2;
                kepPb.BackColor = Color.FromArgb(r, g, b);
            }

            if (kepPb.Bottom >= KepMozgatasPgn.Height)
            {
                y = -2;
                kepPb.BackColor = Color.FromArgb(r, g, b);
            }

            else if (kepPb.Top <= utvonalTxt.Height + utvonalTxt.Location.Y) 
            {
                y = 2;
                kepPb.BackColor = Color.FromArgb(r, g, b);
            }

            kepPb.Left += x;
            kepPb.Top += y;
        }

        private void beallitBtn_Click(object sender, EventArgs e)
        {
            kepPb.ImageLocation = utvonalTxt.Text;
            if (utvonalTxt.Text == "")
            {
                kepPb.ImageLocation = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSBqOC66BJ6B0bIj9BUxoOwF5iFvVBCrHlsaA&s";
            }
            else if (utvonalTxt.Text == "jojo")
            {
                kepPb.ImageLocation = "https://assets.nintendo.com/image/upload/ar_16:9,b_auto:border,c_lpad/b_white/f_auto/q_auto/dpr_1.5/store/software/switch/70010000033003/cb6c1e805897d052d805039418fb6e7b3ef738e9222f3ff407088b7bd69ea294";
            }
        }
        private void kepPb_Click(object sender, EventArgs e)
        {
            kepPb.ImageLocation = "https://static.jojowiki.com/images/8/88/latest/20240224164606/Kars_Infobox_Manga.png";
        }








        //Sudoku
        private void minusBtn_Click(object sender, EventArgs e)
        {
            int szam = int.Parse(meretTxt.Text);
            if (szam > 4) 
            {
                szam--;
            }
            meretTxt.Text = szam.ToString();
        }

        private void plusBtn_Click(object sender, EventArgs e)
        {
            int szam = int.Parse(meretTxt.Text);
            if (szam < 9)
            {
                szam++;
            }
            meretTxt.Text = szam.ToString();
        }

        private void kezdoallapotTxt_TextChanged(object sender, EventArgs e)
        {
            hosszLbl.Text = "Hossz: " + kezdoallapotTxt.Text.Length; 
        }

        private void ellBtn_Click(object sender, EventArgs e)
        {
            int hosszMeret = int.Parse(meretTxt.Text) * int.Parse(meretTxt.Text);
            int kisebb = (hosszMeret - kezdoallapotTxt.Text.Length);
            int nagyobb = (kezdoallapotTxt.Text.Length - hosszMeret);

            if (kezdoallapotTxt.Text.Length == int.Parse(meretTxt.Text) * int.Parse(meretTxt.Text))
            {
                MessageBox.Show("A feladvány megfelelő hosszúságú!");
            }

            else if (kezdoallapotTxt.Text.Length < int.Parse(meretTxt.Text) * int.Parse(meretTxt.Text))
            {
                MessageBox.Show($"A feladvány rövid: kell még {kisebb} számjegy!");
            }

            else if (kezdoallapotTxt.Text.Length > int.Parse(meretTxt.Text) * int.Parse(meretTxt.Text))
            {
                MessageBox.Show($"A feladvány hosszú: törlendő {nagyobb} számjegy!");
            }
        }








        //Lista (Bevásárló lista + Rendelés)
        private void hozzaadBtn_Click(object sender, EventArgs e)
        {
            if (termekTxt.Text == "")
            {
                MessageBox.Show("Nem adtál meg terméket!", "Figyelmeztetés", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                bevasarloListaLb.Items.Add("- " + termekTxt.Text);
                if (bevasarloListaLb.SelectedItems.Count <= 1) 
                {
                    valasztoCb.Items.Add(termekTxt.Text);
                }
            }
        }

        private void bevasarloListaLb_SelectedValueChanged(object sender, EventArgs e)
        {
            bevasarloListaLb.Items.Remove(bevasarloListaLb.SelectedItem);
            valasztoCb.Items.Remove(bevasarloListaLb.SelectedItem);
        }

        private void torlesBtn_Click(object sender, EventArgs e)
        {
            if (!bevasarloListaLb.Enabled)
            {
                bevasarloListaLb.Enabled = true;
                infoLbl.Visible = true;
            }
            else
            {
                bevasarloListaLb.Enabled = false;
                infoLbl.Visible = false;
            }

            infoLbl.Text = "A törléshez válaszd ki a terméket a listából";
        }

        private void kiuritesBtn_Click(object sender, EventArgs e)
        {
            bevasarloListaLb.Items.Clear();
            valasztoCb.Items.Clear();
        }

        private void termekTxt_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                bevasarloListaLb.Items.Add("- " + termekTxt.Text);
            }
        }







        //Lista (Bevásárló lista + Rendelés)
        private void hozzaad2Btn_Click(object sender, EventArgs e)
        {
            if (valasztoCb.Text == "")
            {
                MessageBox.Show("Nem adtál meg vagy választottál ki terméket!", "Figyelmeztetés", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else 
            {
                rendelesLb.Items.Add(valasztoCb.Text);
            }
        }

        private void torles2Btn_Click(object sender, EventArgs e)
        {
            rendelesLb.Items.Remove(rendelesLb.SelectedItem);
        }

        private void rendelesBtn_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Rendelésedet leadtuk!", "Sikeres rendelés", MessageBoxButtons.OK, MessageBoxIcon.Information);
            rendelesLb.Items.Clear();
        }









        //Mozi filmek
        private void felveszBtn_Click(object sender, EventArgs e)
        {
            if (filmNevTxt.Text != "")
            {
                topMoziLb.Items.Add(filmNevTxt.Text);
                helyNud.Maximum = topMoziLb.Items.Count + 1;
            }
            else
            {
                MessageBox.Show("Nem írtál be film címet", "Kitöltetlen mező", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void beszurBtn_Click(object sender, EventArgs e)
        {
            if (filmNevTxt.Text != "")
            {
                topMoziLb.Items.Insert(Convert.ToInt32(helyNud.Value - 1), filmNevTxt.Text);
                helyNud.Maximum = topMoziLb.Items.Count + 1;
            }
            else
            {
                MessageBox.Show("Nem írtál be film címet", "Kitöltetlen mező", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void filmTorlesBtn_Click(object sender, EventArgs e)
        {
            if (topMoziLb.SelectedIndex != -1)
            {
                topMoziLb.Items.Remove(topMoziLb.SelectedItem);
                helyNud.Maximum = topMoziLb.Items.Count + 1;
            }
            else
            {
                MessageBox.Show("Nem jelöltél ki egy filmet se!", "Nincs kijelölt film", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void filmKiuritesBtn_Click(object sender, EventArgs e)
        {
            DialogResult uzenet = MessageBox.Show("Biztosan kiüríted a listát", "Törlés figyelmeztetés", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (uzenet == DialogResult.Yes)
            {
                topMoziLb.Items.Clear();
                helyNud.Maximum = topMoziLb.Items.Count + 1;
            }
        }

        private void masolBtn_Click(object sender, EventArgs e)
        {
            if (topMoziLb.SelectedIndex != -1)
            {
                megnezettFilmLb.Items.Add(topMoziLb.SelectedItem);
                helyNud.Maximum = topMoziLb.Items.Count + 1;
            }
            else
            {
                MessageBox.Show("Nem jelöltél ki egy filmet se!", "Nincs kijelölt film", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void athelyezBtn_Click(object sender, EventArgs e)
        {
            if (topMoziLb.SelectedIndex != -1)
            {
                megnezettFilmLb.Items.Add(topMoziLb.SelectedItem);
                topMoziLb.Items.Remove(topMoziLb.SelectedItem);
                helyNud.Maximum = topMoziLb.Items.Count + 1;
            }
            else 
            {
                MessageBox.Show("Nem jelöltél ki egy filmet se!", "Nincs kijelölt film", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void keresBtn_Click(object sender, EventArgs e)
        {
            //topMoziLb.SelectedItem = filmNevTxt.Text;

            if (filmNevTxt.Text != "") 
            {
                int index = topMoziLb.FindString(filmNevTxt.Text);
                if (index != -1) 
                {
                    topMoziLb.SetSelected(index, true);
                }
            }
        }








        //Web böngésző
        private void ugrasBtn_Click(object sender, EventArgs e)
        {
            webBrowser.Navigate(urlCimCB.Text);
            urlCimCB.Items.Add(urlCimCB.Text);
        }
    }
}
