<?php
    include(ROOT_PATH . "/includes/database.php");

    $hibak = [];
    $siker = '';

    if($_SERVER['REQUEST_METHOD'] === "POST" && isset($_POST['reg_button']))
    {
        $email = trim($_POST['email']);
        $fnev = trim($_POST['fnev']);
        $jelszo = $_POST['jelszo'];
        $jelszo_ujra = $_POST['jelszo_ujra'];

        if(empty($email))
        {
            $hibak[] = "Email cím megadása kötelező!";
        }

        elseif(!filter_var($email, FILTER_VALIDATE_EMAIL))
        {
            $hibak[] = "Érvényes email címet adj meg!";
        }

        if(empty($fnev))
        {
            $hibak[] = "Felhasználónév megadása kötelező!";
        }

        elseif(strlen($fnev) < 4)
        {
            $hibak[] = "A felhasználónév minimum 4 karakter hosszú legyen!";
        }

        if(empty($jelszo))
        {
            $hibak[] = "Jelszó megadása kötelező!";
        }

        elseif(strlen($jelszo) < 6)
        {
            $hibak[] = "A jelszó minimum 6 karakter hosszú legyen!";
        }

        if($jelszo !== $jelszo_ujra)
        {
            $hibak[] = "A jelszavak nem egyeznek!";
        }


        if(empty($hibak))
        {
            try
            {
                $ellenorzes_sql = "SELECT fid FROM felhasznalok WHERE email = ? OR fnev = ?";
                $ellenorzes_stmt = $conn->prepare($ellenorzes_sql);
                $ellenorzes_stmt->execute([$email, $fnev]);

                if($ellenorzes_stmt->rowCount() > 0)
                {
                    $hibak[] = "Ez az email cím vagy felhasználónév már foglalt!";
                }

                else
                {
                    $jelszo_hash = password_hash($jelszo, PASSWORD_DEFAULT);

                    $sql = "INSERT INTO felhasznalok (email, fnev, jelszo, profilkep) 
                            VALUES (?, ?, ?, 'default.png')";
                    
                    $stmt = $conn->prepare($sql);
                    $stmt->execute([$email, $fnev, $jelszo_hash]);

                    $utolso_id = $conn->lastInsertId();
                    $naplo_sql = "INSERT INTO felhasznalo_tevekenyseg (fid, ip, tevekenyseg) VALUES(?, ?, 'regisztracio')";
                    $naplo_stmt = $conn->prepare($naplo_sql);
                    $naplo_stmt->execute([$utolso_id, $_SERVER['REMOTE_ADDR']]);

                    $_SESSION['regisztracio_siker'] = "Sikeres regisztráció! Most már bejelentkezhetsz.";
                    header("Location: " . base_url("login"));
                    exit;
                }
            }

            catch(PDOException $e)
            {
                $hibak[] = "Adatbázis hiba: " . $e->getMessage();
            }
        }
    }
?>