<?php
    include(ROOT_PATH . "/includes/database.php");

    $hibak = [];

    if(isset($_SESSION['regisztracio_siker']))
    {
        $udvozlo_uzenet = $_SESSION['regisztracio_siker'];
        unset($_SESSION['regisztracio_siker']);
    }

    if($_SERVER['REQUEST_METHOD'] === "POST" && isset($_POST['log_button']))
    {
        $fnev = trim($_POST['fnev']);
        $jelszo = $_POST['jelszo'];

        if(empty($fnev))
        {
            $hibak[] = "Felhasználónév vagy email megadása kötelező!";
        }

        if(empty($jelszo))
        {
            $hibak[] = "Jelszó megadása kötelező!";
        }

        if(empty($hibak))
        {
            try
            {
                $sql = "SELECT * FROM felhasznalok WHERE email = ? OR fnev = ?";
                $stmt = $conn->prepare($sql);
                $stmt->execute([$fnev, $fnev]);
                $felhasznalo = $stmt->fetch();

                if($felhasznalo && password_verify($jelszo, $felhasznalo['jelszo']))
                {
                    $_SESSION['fid'] = $felhasznalo['fid'];
                    $_SESSION['fnev'] = $felhasznalo['fnev'];
                    $_SESSION['email'] = $felhasznalo['email'];
                    $_SESSION['szerep'] = $felhasznalo['szerep'];
                    $_SESSION['profilkep'] = $felhasznalo['profilkep'] ?? 'default.png';
                    
                    $belepett_sql = "UPDATE felhasznalok SET belepett = CURRENT_TIMESTAMP WHERE fid = ?";
                    $belepett_stmt = $conn->prepare($belepett_sql);
                    $belepett_stmt->execute([$felhasznalo['fid']]);

                    $naplo_sql = "INSERT INTO felhasznalo_tevekenyseg (fid, ip, tevekenyseg) 
                                VALUES(?, ?, 'bejelentkezes')";
                    
                    $naplo_stmt = $conn->prepare($naplo_sql);
                    $naplo_stmt->execute([$felhasznalo['fid'], $_SERVER['REMOTE_ADDR']]);

                    header("Location: " . BASE_URL . "/");
                    exit;
                }

                else
                {
                    $hibak[] = "Hibás felhasználónév / email vagy jelszó!";

                    if($felhasznalo)
                    {
                        $naplo_sql = "INSERT INTO felhasznalo_tevekenyseg (fid, ip, tevekenyseg, sikeresseg) 
                                    VALUES(?, ?, 'bejelentkezes', 'sikertelen')";
                        
                        $naplo_stmt = $conn->prepare($naplo_sql);
                        $naplo_stmt->execute([$felhasznalo['fid'], $_SERVER['REMOTE_ADDR']]);
                    }
                }
            }

            catch(PDOException $e)
            {
                $hibak[] = "Adatbázis hiba: " . $e->getMessage();
            }
        }
    }
?>