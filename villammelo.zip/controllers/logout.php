<?php
require_once __DIR__ . '/../includes/config.php';
require_once ROOT_PATH . '/includes/database.php';

if(isset($_SESSION['fid']))
{
    $naplo_sql = "INSERT INTO felhasznalo_tevekenyseg (fid, ip, tevekenyseg) 
                VALUES(?, ?, 'kijelentkezes')";
    $naplo_stmt = $conn->prepare($naplo_sql);
    $naplo_stmt->execute([$_SESSION['fid'], $_SERVER['REMOTE_ADDR']]);
}

session_destroy();

header("Location: " . BASE_URL . "/");
exit;
?>
