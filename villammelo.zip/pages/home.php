<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Főoldal - Villám meló</title>
</head>
<body>
    <div class='home_box'>
        <section class='home_content_sec'>
            <div class='home_content'>
                <h1>Találd meg álmaid munkáját</h1>
                <p>Csatlakozz több ezer munkáltatóhoz és jelentkezz a legjobb álláslehetőségekre pár kattintással.</p>
            </div>
        </section>

        <section class='home_steps_sec'>
            <div class='home_steps'>
                <div class='home_stem'>
                    <div class="home_step_icon">1</div>
                    <h3>Regisztráció</h3>
                    <p>Hozz létre egy ingyenes fiókot és töltsd ki profilodat</p>
                </div>
                <div class='home_stem'>
                    <div class="home_step_icon">2</div>
                    <h3>Munkák tallózása</h3>
                    <p>Böngéssz a kategóriák között vagy keress konkrét pozíciókat</p>
                </div>
                <div class='home_stem'>
                    <div class="home_step_icon">3</div>
                    <h3>Jelentkezés</h3>
                    <p>Jelentkezz pár kattintással és kövesd jelentkezésed állapotát</p>
                </div>
                <div class='home_stem'>
                    <div class="home_step_icon">4</div>
                    <h3>Interjú</h3>
                    <p>Kapj meghívást interjúra és találd meg álmaid állását</p>
                </div>
            </div>
        </section>
    </div>
</body>
</html>