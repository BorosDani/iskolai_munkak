<?php
    $base = BASE_URL;
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bejelentkezés - Villám Meló</title>
</head>
<body>
    <div class='log_box'>
        <h1>Bejelentkezés</h1>

        <form method="post" action="">
            <?php if(isset($udvozlo_uzenet)):?>
                <div class='log_udv'>
                    <p><?php echo $udvozlo_uzenet;?></p>
                </div>
            <?php endif?>

            <?php if(!empty($hibak)):?>
                <div class='log_hibak'>
                    <?php foreach($hibak as $hiba):?>
                        <p class='log_hiba'><?php echo $hiba;?></p>
                    <?php endforeach?>
                </div>
            <?php endif?>

            <div class='log_input'>
                <input type="text" id='fnev' name='fnev' placeholder="Felhasználó vagy email" value="<?php echo htmlspecialchars($fnev ?? '');?>" required>
                <input type="password" id='jelszo' name='jelszo' placeholder="Jelszó" required>
            </div>

            <button type="submit" name='log_button' class='log_button'>Bejelentkezés</button>
            
            <div class='log_links'>
                <p>Nincs még fiókod? <a href="<?= $base ?>/register">Regisztrálj</a></p>
                <p>Vissza a <a href="<?= $base ?>">főoldalra</a></p>
            </div>        
        </form>
    </div>
</body>
</html>