<?php
    $base = BASE_URL;
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Regisztráció - Villám Meló</title>
</head>
<body>
    <div class='reg_box'>
        <form method="post" action="">
            <h1>Regisztráció</h1>
            
            <?php if(!empty($hibak)):?>
                <div class='reg_hibak'>
                    <?php foreach($hibak as $hiba):?>
                        <p class='reg_hiba'><?php echo $hiba;?></p>
                    <?php endforeach;?>
                </div>
            <?php endif;?>

            <div class='reg_input'>
                <input type="email" id='email' name='email' placeholder="Email" value="<?php echo htmlspecialchars($email ?? '');?>" required>
                <input type="text" id='fnev' name='fnev' placeholder="Felhasználónév" value="<?php echo htmlspecialchars($fnev ?? '');?>" required>
                <input type="password" id='jelszo' name='jelszo' placeholder="Jelszó" required>
                <input type="password" id='jelszo_ujra' name='jelszo_ujra' placeholder="Jelszó ismét" required>
            </div>

            <button type="submit" name='reg_button' class='reg_button'>Regisztráció</button>
        </form>

        <div class='reg_links'>
            <p>Már van fiókod? <a href="<?= $base ?>/login">Jelentkezz be!</a></p>
            <p>Vissza a <a href="<?= $base ?>">főoldalra</a></p>
        </div>
    </div>
</body>
</html>