<?php
    $base = BASE_URL;
?>

<div class="header_box">
    <div class="header_left">
        <a href="<?= $base ?>">
            <img src="<?= $base ?>/assets/images/logo.png" alt="Villám Meló logó">
            <p>Villám Meló</p>
        </a>
    </div>

    <div class="header_mid">
        <a href="<?= $base ?>">Főoldal</a>
        <a href="<?= $base ?>/about">Rólunk</a>
        <a href="<?= $base ?>/contact">Elérhetőség</a>
        <a href="<?= $base ?>/jobs">Munkák</a>
    </div>

    <div class="header_right">
        <?php if (!isset($_SESSION['fid'])): ?>
            <a href="<?= $base ?>/login">Bejelentkezés</a>
            <a href="<?= $base ?>/register">Regisztráció</a>
        <?php else: ?>
            <div class="header_profile_dropdown">
                <a href="<?= $base ?>/profile" class="profile-link">
                    <img src="<?= $base ?>/assets/images/profile/<?= isset($_SESSION['profile_image']) ? $_SESSION['profile_image'] : 'default.png' ?>" alt="Profilkép">
                </a>
                <div class="header_dropdown_menu">
                    <a href="<?= $base ?>/profile">Profilom</a>
                    <a href="<?= $base ?>/jobUpload">Munka feltöltése</a>
                    <a href="<?= $base ?>/myJobs">Munkáim</a>
                    <a href="<?= $base ?>/applications">Jelentkezéseim</a>
                    <hr>
                    <a href="<?= base_url('controllers/logout.php') ?>">Kijelentkezés</a>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
