<?php
// SESSION indítása (szükséges a login/logout és user session kezeléshez)
if (session_status() === PHP_SESSION_NONE) 
{
    session_start();
}

// Gyökérútvonalak és URL-ek
define('ROOT_PATH', dirname(__DIR__));
define('BASE_URL', '/villammelo');

date_default_timezone_set('Europe/Budapest');

function base_url($path = '') 
{
    return BASE_URL . '/' . ltrim($path, '/');
}
?>
