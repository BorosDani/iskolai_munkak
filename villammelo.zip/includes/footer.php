<div class='footer_box'>
    <div class='footer_left'>
        <p>Elérhetőség</p>
    </div>

    <div class='footer_right'>
        <p>Tagok száma</p>
        <p>Munkák száma</p>
        <p>Elégedett ügyfelek száma</p>
    </div>

    <div class='footer_mid_bottom'>
        <footer>
            <p>&copy; <?= date('Y') ?> VillámMeló. Minden jog fenntartva.</p>
        </footer>
    </div>
</div>