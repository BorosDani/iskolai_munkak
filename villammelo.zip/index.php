<?php
require_once "includes/config.php";

$url = $_GET['url'] ?? 'home';
$pages = ['home', 'login', 'register', 'jobs', 'profile', 'contact', 'about'];
//$pageWDB = ['home','login', 'register', 'jobs', 'profile'];
$noLayoutPages = ['login', 'register'];

if (!in_array($url, $pages)) $url = '404';

// AUTOMATIKUS CONTROLLER INCLUDE
$controllerFile = ROOT_PATH . "/controllers/{$url}c.php";
if (file_exists($controllerFile)) 
{
    include $controllerFile;
}
/* LEHET KÉSŐBB KELL!
if (in_array($url, $pageWDB)) 
{
    require_once ROOT_PATH . '/includes/database.php';
}
*/

if (!in_array($url, $noLayoutPages)) 
{
    include ROOT_PATH . '/includes/header.php';
}

include ROOT_PATH . "/pages/{$url}.php";

if (!in_array($url, $noLayoutPages)) 
{
    include ROOT_PATH . '/includes/footer.php';
}
