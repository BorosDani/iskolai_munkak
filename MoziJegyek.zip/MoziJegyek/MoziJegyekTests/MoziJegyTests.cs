﻿using MoziJegyek;

namespace MoziJegyekTests
{
    [TestClass]
    public class MoziJegyTests
    {
        [TestMethod]
        public void Husz_Szazalek_Kedvezmeny_Levonodik()
        {
            double kezdoErtek = 5000;
            double jegyKedvezmeny = 20;
            double vartEredmeny = 3400;
            // Arrange
            MoziJegy jegy = new MoziJegy("Teszt Elek", kezdoErtek);

            // Act
            jegy.Kedvezmeny(jegyKedvezmeny);

            // Assert
            double jelenlegiEgyenleg = jegy.Egyenleg;
            Assert.AreEqual(vartEredmeny, jelenlegiEgyenleg, 0.001, $"20% kedvezménnyel {vartEredmeny} egyenlegnek kellene lennie!");
        }
    }
}