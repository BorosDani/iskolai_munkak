﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MoziJegyek
{
    public class MoziJegy
    {
        private readonly string jegyetVasarlo_Neve;
        private double jegyetVasarlo_Egyenlege;

        private const double jegyAra = 2000;
        private double fizetendo;

        private MoziJegy() { }

        public MoziJegy(string VasarloNeve, double Egyenleg) 
        {
            jegyetVasarlo_Neve = VasarloNeve;
            jegyetVasarlo_Egyenlege = Egyenleg;
        }

        public string VasarloNeve 
        {
            get { return jegyetVasarlo_Neve; }
        }

        public double Egyenleg 
        {
            get { return jegyetVasarlo_Egyenlege; }
        }

        public void Kedvezmeny(double szazalek)
        {
            if (szazalek < 0 || szazalek > 100)
            {
                throw new ArgumentOutOfRangeException("szazalek");
            }

            fizetendo = jegyAra * (1 - szazalek / 100);
            jegyetVasarlo_Egyenlege -= fizetendo;
        }

        static void Main(string[] args)
        {
            MoziJegy jegy = new MoziJegy("Kiss Béla", 5000);

            jegy.Kedvezmeny(20);

            Console.WriteLine("Vásárló: " + jegy.VasarloNeve);
            Console.WriteLine("Maradék egyenleg: " + jegy.Egyenleg);
            //Console.ReadLine();
        }
    }
}
