﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cbradio
{
    class Program
    {
        static void Main(string[] args)
        {
            cbradio();
            Console.ReadLine();
        }
        private static void cbradio() 
        {
            feladat2();
            feladat3();
            feladat4();
            feladat5();
        }

        struct CBRadioStruktura
        {
            public int Ora;
            public int Perc;
            public int AdasDb;
            public string Nev;
        }
        static List<CBRadioStruktura> adatok = new List<CBRadioStruktura>();

        private static void feladat2() 
        {
            //Beolvasás
            StreamReader olvasocsatorna = new StreamReader(@"Z:\programozas\CB-radio\cb.txt");
            string elsosor = olvasocsatorna.ReadLine();
            string sor;

            string[] darabol;

            while (!olvasocsatorna.EndOfStream) 
            {
                sor = olvasocsatorna.ReadLine();
                darabol = sor.Split(';');

                CBRadioStruktura radio = new CBRadioStruktura();

                radio.Ora = int.Parse(darabol[0]);
                radio.Perc = int.Parse(darabol[1]);
                radio.AdasDb = int.Parse(darabol[2]);
                radio.Nev = darabol[3];

                adatok.Add(radio);
            }
            Console.WriteLine("1-2 Feladat megtörtént!\n\n");
        }

        private static void feladat3() 
        {
            int bejegyzesek_szama = 0;
            for (int i = 0; i < adatok.Count(); i++)
            {
                bejegyzesek_szama++;
            }

            Console.WriteLine("3. Feladat: Bejegyzések száma: {0} db", bejegyzesek_szama);
        }

        private static void feladat4() 
        {
            int index = 0;
            bool egyperc_negyadas = false;
            while (adatok[index].AdasDb != 4) 
            {
                index++;
                if (adatok[index].AdasDb == 4) 
                {
                    egyperc_negyadas = true;
                }
            }

            if (egyperc_negyadas)
            {
                Console.WriteLine("4. Feladat: Volt négy adást indító sofőr.");
            }
            else 
            {
                Console.WriteLine("4. Feladat: Nem volt négy adást indító sofőr.");
            }
        }

        private static void feladat5() 
        {
            Console.WriteLine("5. Feladat: Kérek egy nevet: ");
            string sofor_nev = Console.ReadLine();

            if
        }
    }
}