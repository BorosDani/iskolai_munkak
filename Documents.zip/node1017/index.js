const express = require("express");
const app = express();
const port = 3000;

app.listen(port, function()
{
    console.log(`Server is running on port: ${port}`);
})

app.get("/", function(req, res)
{
    res.send("<h1>Helló Kristály!</h1>");
})

app.get("/weiss", function(req, res)
{
    res.send("<h1>Helló Manfréd!</h1>");
})

app.use("/home", express.static("public"));