﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Idozito
{
    public partial class Form1 : Form
    {
        DateTime startIdo;
        TimeSpan elteltIdo, taroltElteltIdo;

        public Form1()
        {
            InitializeComponent();
            oraLbl.Text = "00:00:00:000";
            stopperLbl.Text = "00:00:00:000";
            pauseBtn.Enabled = false;
            timer3.Enabled = true;
        }

        private void startBtn_MouseClick(object sender, MouseEventArgs e)
        {
            timer1.Enabled = true;
            startBtn.Enabled = false;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            oraLbl.Text = DateTime.Now.ToString("HH:mm:ss:fff");
        }

        private void stopBtn_MouseClick(object sender, MouseEventArgs e)
        {
            timer1.Enabled = false;
            startBtn.Enabled = true;
            oraLbl.Text = "00:00:00:000";
        }




        private void startBtn2_MouseClick(object sender, MouseEventArgs e)
        {
            startIdo = DateTime.Now;

            pauseBtn.Enabled = true;
            timer2.Enabled = true;

            if (pauseBtn.Text == "Continue")
            {
                pauseBtn.Text = "Pause";
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            elteltIdo = DateTime.Now - startIdo + taroltElteltIdo;

            stopperLbl.Text = elteltIdo.ToString(@"hh\:mm\:ss\:fff");
        }

        private void pauseBtn_MouseClick(object sender, MouseEventArgs e)
        {
            timer2.Enabled = false;
            startBtn2.Enabled = true;

            if (pauseBtn.Text == "Pause")
            {
                pauseBtn.Text = "Continue";
                timer2.Enabled = false;
                taroltElteltIdo += taroltElteltIdo;
            }
            else 
            {
                pauseBtn.Text = "Pause";
                timer2.Enabled = true;
                startIdo = DateTime.Now - elteltIdo;
            }
        }

        private void StopperStop_MouseClick(object sender, MouseEventArgs e)
        {
            stopperLbl.Text = "00:00:00:000";

            timer2.Enabled = false;
            pauseBtn.Enabled = false;
            startBtn2.Enabled = true;

            if (pauseBtn.Text == "Continue") 
            {
                pauseBtn.Text = "Pause";
            }
        }




        int vx = 2;
        int vy = 0;
        private void timer3_Tick(object sender, EventArgs e)
        {
            int ujx = MozgoFLBL.Left + vx;
            int ujy = MozgoFLBL.Top + vy;
            MozgoFLBL.Location = new Point(ujx, ujy);

            if (MozgoFLBL.Width > MozgoPTg.Width) 
            {

            }
        }
    }
}
