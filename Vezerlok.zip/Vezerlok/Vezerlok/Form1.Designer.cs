﻿namespace Vezerlok
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.vezerlokBox = new System.Windows.Forms.GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.kekSB = new System.Windows.Forms.HScrollBar();
            this.zoldSB = new System.Windows.Forms.HScrollBar();
            this.pirosSB = new System.Windows.Forms.HScrollBar();
            this.kekLbl = new System.Windows.Forms.Label();
            this.zoldLbl = new System.Windows.Forms.Label();
            this.pirosLbl = new System.Windows.Forms.Label();
            this.pirosSzamLbl = new System.Windows.Forms.Label();
            this.zoldSzamLbl = new System.Windows.Forms.Label();
            this.kekSzamLbl = new System.Windows.Forms.Label();
            this.vezerlokBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // vezerlokBox
            // 
            this.vezerlokBox.Controls.Add(this.kekSzamLbl);
            this.vezerlokBox.Controls.Add(this.zoldSzamLbl);
            this.vezerlokBox.Controls.Add(this.pirosSzamLbl);
            this.vezerlokBox.Controls.Add(this.panel1);
            this.vezerlokBox.Controls.Add(this.kekSB);
            this.vezerlokBox.Controls.Add(this.zoldSB);
            this.vezerlokBox.Controls.Add(this.pirosSB);
            this.vezerlokBox.Controls.Add(this.kekLbl);
            this.vezerlokBox.Controls.Add(this.zoldLbl);
            this.vezerlokBox.Controls.Add(this.pirosLbl);
            this.vezerlokBox.Location = new System.Drawing.Point(60, 60);
            this.vezerlokBox.Name = "vezerlokBox";
            this.vezerlokBox.Size = new System.Drawing.Size(550, 350);
            this.vezerlokBox.TabIndex = 0;
            this.vezerlokBox.TabStop = false;
            this.vezerlokBox.Text = "Vezérlők";
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(380, 66);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(136, 192);
            this.panel1.TabIndex = 6;
            // 
            // kekSB
            // 
            this.kekSB.Location = new System.Drawing.Point(97, 236);
            this.kekSB.Name = "kekSB";
            this.kekSB.Size = new System.Drawing.Size(240, 30);
            this.kekSB.TabIndex = 5;
            this.kekSB.Scroll += new System.Windows.Forms.ScrollEventHandler(this.kekSB_Scroll);
            // 
            // zoldSB
            // 
            this.zoldSB.Location = new System.Drawing.Point(97, 149);
            this.zoldSB.Name = "zoldSB";
            this.zoldSB.Size = new System.Drawing.Size(240, 30);
            this.zoldSB.TabIndex = 4;
            this.zoldSB.Scroll += new System.Windows.Forms.ScrollEventHandler(this.zoldSB_Scroll);
            // 
            // pirosSB
            // 
            this.pirosSB.Location = new System.Drawing.Point(97, 64);
            this.pirosSB.Name = "pirosSB";
            this.pirosSB.Size = new System.Drawing.Size(240, 30);
            this.pirosSB.TabIndex = 3;
            this.pirosSB.Scroll += new System.Windows.Forms.ScrollEventHandler(this.pirosSB_Scroll);
            // 
            // kekLbl
            // 
            this.kekLbl.AutoSize = true;
            this.kekLbl.Location = new System.Drawing.Point(40, 245);
            this.kekLbl.Name = "kekLbl";
            this.kekLbl.Size = new System.Drawing.Size(26, 13);
            this.kekLbl.TabIndex = 2;
            this.kekLbl.Text = "Kék";
            // 
            // zoldLbl
            // 
            this.zoldLbl.AutoSize = true;
            this.zoldLbl.Location = new System.Drawing.Point(40, 158);
            this.zoldLbl.Name = "zoldLbl";
            this.zoldLbl.Size = new System.Drawing.Size(28, 13);
            this.zoldLbl.TabIndex = 1;
            this.zoldLbl.Text = "Zöld";
            // 
            // pirosLbl
            // 
            this.pirosLbl.AutoSize = true;
            this.pirosLbl.Location = new System.Drawing.Point(37, 70);
            this.pirosLbl.Name = "pirosLbl";
            this.pirosLbl.Size = new System.Drawing.Size(30, 13);
            this.pirosLbl.TabIndex = 0;
            this.pirosLbl.Text = "Piros";
            // 
            // pirosSzamLbl
            // 
            this.pirosSzamLbl.AutoSize = true;
            this.pirosSzamLbl.Location = new System.Drawing.Point(341, 70);
            this.pirosSzamLbl.Name = "pirosSzamLbl";
            this.pirosSzamLbl.Size = new System.Drawing.Size(13, 13);
            this.pirosSzamLbl.TabIndex = 7;
            this.pirosSzamLbl.Text = "0";
            // 
            // zoldSzamLbl
            // 
            this.zoldSzamLbl.AutoSize = true;
            this.zoldSzamLbl.Location = new System.Drawing.Point(339, 158);
            this.zoldSzamLbl.Name = "zoldSzamLbl";
            this.zoldSzamLbl.Size = new System.Drawing.Size(13, 13);
            this.zoldSzamLbl.TabIndex = 8;
            this.zoldSzamLbl.Text = "0";
            // 
            // kekSzamLbl
            // 
            this.kekSzamLbl.AutoSize = true;
            this.kekSzamLbl.Location = new System.Drawing.Point(341, 245);
            this.kekSzamLbl.Name = "kekSzamLbl";
            this.kekSzamLbl.Size = new System.Drawing.Size(13, 13);
            this.kekSzamLbl.TabIndex = 9;
            this.kekSzamLbl.Text = "0";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(684, 461);
            this.Controls.Add(this.vezerlokBox);
            this.Name = "Form1";
            this.Text = "Színkeverő";
            this.vezerlokBox.ResumeLayout(false);
            this.vezerlokBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox vezerlokBox;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.HScrollBar kekSB;
        private System.Windows.Forms.HScrollBar zoldSB;
        private System.Windows.Forms.HScrollBar pirosSB;
        private System.Windows.Forms.Label kekLbl;
        private System.Windows.Forms.Label zoldLbl;
        private System.Windows.Forms.Label pirosLbl;
        private System.Windows.Forms.Label kekSzamLbl;
        private System.Windows.Forms.Label zoldSzamLbl;
        private System.Windows.Forms.Label pirosSzamLbl;
    }
}

