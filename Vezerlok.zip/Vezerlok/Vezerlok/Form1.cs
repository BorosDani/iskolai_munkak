﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vezerlok
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        static int pirosCsuszkaSzam = 0;
        static int zoldCsuszkaSzam = 0;
        static int kekCsuszkaSzam = 0;
        private void pirosSB_Scroll(object sender, ScrollEventArgs e)
        {
            if (pirosCsuszkaSzam < 255) 
            {
                pirosCsuszkaSzam++;
            }

            pirosSzamLbl.Text = pirosCsuszkaSzam.ToString();
            panel1.BackColor = Color.FromArgb(pirosCsuszkaSzam, zoldCsuszkaSzam, kekCsuszkaSzam);
        }

        private void zoldSB_Scroll(object sender, ScrollEventArgs e)
        {
            if (zoldCsuszkaSzam < 255)
            {
                zoldCsuszkaSzam++;
            }

            zoldSzamLbl.Text = zoldCsuszkaSzam.ToString();
            panel1.BackColor = Color.FromArgb(pirosCsuszkaSzam, zoldCsuszkaSzam, kekCsuszkaSzam);
        }

        private void kekSB_Scroll(object sender, ScrollEventArgs e)
        {
            if (kekCsuszkaSzam < 255)
            {
                kekCsuszkaSzam++;
            }

            kekSzamLbl.Text = kekCsuszkaSzam.ToString();
            panel1.BackColor = Color.FromArgb(pirosCsuszkaSzam, zoldCsuszkaSzam, kekCsuszkaSzam);
        }
    }
}
